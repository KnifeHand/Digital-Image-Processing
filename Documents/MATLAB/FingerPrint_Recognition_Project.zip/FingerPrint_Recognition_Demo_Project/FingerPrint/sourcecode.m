% -----Project : Fingerprint Recognition Project-----
%----------------------------------------------------
% Please Donate to obtain the Full source code.
% Link : https://matlab-recognition-code.com/matlab-fingerprint-recognition-system-full-source-code/
% 
% Developer: PhD, Hamdi Boukamcha, Faculty of Science of Monastir, Tunisia.
% Email: Contact@matlab-recognition-code.com
% WhatsAPP: +21650674269
% Website: https://Matlab-Recognition-Code.com
%
