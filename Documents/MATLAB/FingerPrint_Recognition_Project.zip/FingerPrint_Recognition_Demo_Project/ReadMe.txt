******* Project : Fingerprint Recognition System *******


Attention : (This Demo Work only with Matlab 64 Bit, you need the full source code to work both in 32, 64 bits ).


- Description: Discover The Least Developed Technique For FingerPrint Recognition,Based On The Matching with The Euclidean Distance & Filter Gabor.
- How Work :  Just Run This file in Matlab PathWork : "Finger_Print_Project.p" 
- Tutorial video: https://youtu.be/OtvB_Ni28G0

********************** Please Donate to obtain the Full source code.**************************
Link : https://matlab-recognition-code.com/matlab-fingerprint-recognition-system-full-source-code/
---------------------------------------------------------------------------------

Developer: PhD, Hamdi Boukamcha, Faculty of Science of Monastir, Tunisia.
Email: Contact@matlab-recognition-code.com
WhatsAPP: +21650674269
Website: https://Matlab-Recognition-Code.com


Ps : Looking for a Custom Project For Recognition Fingerprint!! Send Us What Do You Need Exactly , We Will Take Care Of Your Project !


A list of fingerprint databases available on the web:
----------------------------------------------------
http://bias.csr.unibo.it/fvc2004/download.asp
http://bias.csr.unibo.it/fvc2002/download.asp
http://bias.csr.unibo.it/fvc2000/download.asp
http://www.neurotechnologija.com/download.html
http://www.biometrix.at/fp-images.zip
http://tima.imag.fr/mns/research/finger/fingerprint/
http://www.owlnet.rice.edu/~cronoman/Elec%20301%20Project/Database%20of%20Images/
http://bias.csr.unibo.it/research/biolab/Fingdb.zip
http://bias.csr.unibo.it/research/biolab/DsPami97.zip






